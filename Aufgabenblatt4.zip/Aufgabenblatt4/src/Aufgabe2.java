/*
    Aufgabe 2) Eindimensionale Arrays und File I/O
*/
import java.awt.*;

public class Aufgabe2 {
    
    private static String[] readFileData(String fileName, int lineStart, int lineEnd) {
        In fileReader = new In(fileName);
        
        //TODO: Implementieren Sie hier Ihre Lösung für die Angabe
        return null; //Zeile kann geändert oder entfernt werden.
    }
    
    private static void extractData(String[] dataArray, int[] resultArray, int numColumn, int entriesPerYear) {
        //TODO: Implementieren Sie hier Ihre Lösung für die Angabe
    }
    
    
    private static void drawChart(int[] frostDays, int[] iceDays, int[] summerDays, int[] heatDays) {
        int width = 1230;
        int height = 500;
        StdDraw.setCanvasSize(width, height);
        StdDraw.setXscale(0, width);
        StdDraw.setYscale(-height / 2, height / 2);
        
        //TODO: Implementieren Sie hier Ihre Lösung für die Angabe
    }
    
    public static void main(String[] args) {
        //TODO: Implementieren Sie hier Ihre Lösung für die Angabe
    }
}


